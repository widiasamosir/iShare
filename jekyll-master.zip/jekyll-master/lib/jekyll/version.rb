# frozen_string_literal: true

module Jekyll
  VERSION = "3.8.5"
end
